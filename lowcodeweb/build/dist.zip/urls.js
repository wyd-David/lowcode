var CONFIG = {
  // url: "http://10.7.7.72:8087", //焕伟//dev-api
  // url: "http://10.7.3.154:8087", //金辉//dev-api
  // url: "http://10.7.2.46:8087", //雷靖
  // url: "http://10.7.6.185:8087",
  // url: "http://10.7.2.119:8087"

  // 工作流地址
  // workflow_url: "http://10.201.62.254:8084",
  // 生产环境
  // url: " http://yjxt.gmcc.net", //prod-api
  // uat环境
  // url: "http://10.201.61.149:18084", //prod-api
  // socketUrl: "ws://10.201.61.149:18084",
  //测试环境
  url: "http://10.201.62.254:18084", //prod-api
};
